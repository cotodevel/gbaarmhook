//Prototypes for ichfly's extended FAT stuff
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "fatfile.h" //required for linking FILE_STRUCT and other FAT related initializers

//extra settings for ownfilebuffer
#define chucksizeinsec 1 //1,2,4,8
#define buffslots 255
#define chucksize 0x200*chucksizeinsec

#ifdef __cplusplus
extern "C" {
#endif

extern u32 *sectortabel;
extern u32 current_pointer;
extern u32 allocedfild[buffslots];
extern u8 * greatownfilebuffer;

extern void * lastopen;
extern void * lastopenlocked;

//extern int _FAT_syncToDisc(FILE_STRUCT* file);
extern PARTITION* partitionlocked;
extern FN_MEDIUM_READSECTORS	readSectorslocked;

extern void generatefilemap(int);
extern void getandpatchmap(int offsetgba,int offsetthisfile);

//extended ichfly gbarom mappers
extern void ichfly_readfrom(FILE* fd, int pos,char *ptr, size_t len);
extern void ichfly_readdma_rom(u32 pos,u8 *ptr,u32 c,int readal);
extern u8 ichfly_readu8(unsigned int pos);
extern u16 ichfly_readu16(unsigned int pos);
extern u32 ichfly_readu32(unsigned int pos);

extern u32 ichfly_readu32extern(unsigned int pos);
extern u16 ichfly_readu16extern(unsigned int pos);
extern u8 ichfly_readu8extern(unsigned int pos);

#ifdef __cplusplus
}
#endif