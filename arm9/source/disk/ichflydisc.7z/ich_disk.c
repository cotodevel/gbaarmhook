#include <nds.h>
#include <fat.h>
#include <filesystem.h>
#include <dirent.h>
#include <unistd.h>    // for sbrk()

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include <fcntl.h>
#include <errno.h>
#include <ctype.h>

#include "ich_disk.h"
#include "fatfile.h"
#include "cache.h"
#include "file_allocation_table.h"
#include "bit_ops.h"
#include "filetime.h"
#include "lock.h"

u32 *sectortabel;
void * lastopen;
void * lastopenlocked;

PARTITION* partitionlocked;
FN_MEDIUM_READSECTORS	readSectorslocked;
u32 current_pointer = 0;
u32 allocedfild[buffslots];
u8* greatownfilebuffer;


//int romSize = 0x200000; //test normal 0x2000000 current 1/10 oh no only 2.4 MB <-- already setup in GBA.c
//same as ichflyfilestreamsize //which is used by some readmc function

inline u8 ichfly_readu8(unsigned int pos){ //need lockup //ori: static inline u8 ichfly_readu8(unsigned int pos)

//very important to link
extern u32 *sectortabel;
extern u8 * greatownfilebuffer;
extern u32 allocedfild[buffslots];

	// Calculate the sector and byte of the current position,
	// and store them
	unsigned int sectoroffset = pos % chucksize;
	unsigned int mappoffset = pos / chucksize;
	
	u8* asd = (u8*)(sectortabel[mappoffset*2]);

	//iprintf("sector tabel+ mappoffset\n");
	//for(i=0;i<32;i++){
	//iprintf("%02X ",*(sectortabel+((i*2)+1)));
	//}
	
	if(asd != (u8*)0x0)return asd[sectoroffset]; //found exit here

	sectortabel[allocedfild[current_pointer]] = 0x0; //reset

	allocedfild[current_pointer] = mappoffset*2; //set new slot
	asd = greatownfilebuffer + current_pointer * chucksize;
	sectortabel[mappoffset*2] = (u32)asd;

	readSectorslocked(sectortabel[mappoffset*2 + 1], chucksizeinsec, asd);

	#ifdef countpagefault
	pagefehler++; //pagefaults
	#endif

	current_pointer++;
	if(current_pointer == buffslots)current_pointer = 0;
	
	return asd[sectoroffset];
}
inline u16 ichfly_readu16(unsigned int pos){ //need lockup //ori: static inline u16 ichfly_readu16(unsigned int pos)

//very important to link
extern u32 *sectortabel;
extern u8 * greatownfilebuffer;
extern u32 allocedfild[buffslots];

	// Calculate the sector and byte of the current position,
	// and store them
	unsigned int sectoroffset = pos % chucksize;
	unsigned int mappoffset = pos / chucksize;
	
	u8* asd = (u8*)(sectortabel[mappoffset*2]);
	
	if(asd != (u8*)0x0)return *(u16*)(&asd[sectoroffset]); //found exit here

	sectortabel[allocedfild[current_pointer]] = 0x0; //clear old slot

	allocedfild[current_pointer] = mappoffset*2; //set new slot
	asd = greatownfilebuffer + current_pointer * chucksize;
	sectortabel[mappoffset*2] = (u32)asd;
	
	readSectorslocked(sectortabel[mappoffset*2 + 1], chucksizeinsec, asd);

	#ifdef countpagefault
	pagefehler++; //pagefaults
	#endif

	current_pointer++;
	if(current_pointer == buffslots)current_pointer = 0;
	
	return *(u16*)(&asd[sectoroffset]);
}
inline u32 ichfly_readu32(unsigned int pos){ //need lockup //ori: static inline u32 ichfly_readu32(unsigned int pos)

//very important to link
extern u32 *sectortabel;
extern u8 * greatownfilebuffer;
extern u32 allocedfild[buffslots];

	// Calculate the sector and byte of the current position,
	// and store them
	unsigned int sectoroffset = pos % chucksize;
	unsigned int mappoffset = pos / chucksize;
	
	u8* asd = (u8*)(sectortabel[mappoffset*2]);
	
	if(asd != (u8*)0x0)return *(u32*)(&asd[sectoroffset]); //found exit here

	sectortabel[allocedfild[current_pointer]] = 0x0;

	allocedfild[current_pointer] = mappoffset*2; //set new slot
	asd = greatownfilebuffer + current_pointer * chucksize;
	sectortabel[mappoffset*2] = (u32)asd;

	readSectorslocked(sectortabel[mappoffset*2 + 1], chucksizeinsec, asd);
	
	#ifdef countpagefault
	pagefehler++; //pagefaults
	#endif

	current_pointer++;
	if(current_pointer == buffslots)current_pointer = 0;
	
	return *(u32*)(&asd[sectoroffset]);
}

//need lockup only alined is not working
//emulated DMA for GBA
inline void ichfly_readdma_rom(u32 pos,u8 *ptr,u32 c,int readal){
// Calculate the sector and byte of the current position,
// and store them
int sectoroffset = 0;
int mappoffset = 0;

int currsize = 0;

if(readal == 4){ //32 Bit
	
	while(c > 0){
		
		sectoroffset = (pos % chucksize) /4;
		mappoffset = pos / chucksize;
		currsize = (chucksize / 4) - sectoroffset;
		
		if(currsize == 0)currsize = chucksize / 4;
		
		if(currsize > (int)c) currsize = (int)c;
		
		u32* asd = (u32*)(sectortabel[mappoffset*2]);
			
			if(asd != (u32*)0x0){//found exit here
				int i = 0; //copy
				while(currsize > i){
					*(u32*)(&ptr[i*4]) = asd[sectoroffset + i];
					i++;
				}
				c -= currsize;
				pos += (currsize * 4);
				ptr += (currsize * 4);
				continue;
			}
			
			sectortabel[allocedfild[current_pointer]] = 0x0;
			allocedfild[current_pointer] = mappoffset*2; //set new slot
			asd = (u32*)(greatownfilebuffer + current_pointer * chucksize);
			sectortabel[mappoffset*2] = (u32)asd;
			
			readSectorslocked(sectortabel[mappoffset*2 + 1], chucksizeinsec, asd);
			#ifdef countpagefault
			pagefehler++; //pagefaults
			#endif
			
			current_pointer++;
			if(current_pointer == buffslots) current_pointer = 0;
			int i = 0; //copy
			while(currsize > i){
				*(u32*)(&ptr[i*4]) = asd[sectoroffset + i];
				i++;
			}
			c -= currsize;
			pos += (currsize * 4);
			ptr += (currsize * 4);
	}
}
//16 Bit
else{
	while(c > 0){
	
	sectoroffset = (pos % chucksize) / 2;
	mappoffset = pos / chucksize;
	currsize = (chucksize / 2) - sectoroffset;
		
	if(currsize == 0)currsize = chucksize / 2;
	if(currsize > (int)c) currsize = (int)c;

	u16* asd = (u16*)(sectortabel[mappoffset*2]);
	//iprintf("%X %X %X %X %X %X\n\r",sectoroffset,mappoffset,currsize,pos,c,chucksize);
	if(asd != (u16*)0x0){ //found exit here
		int i = 0; //copy
		while(currsize > i){
			*(u16*)(&ptr[i*2]) = asd[sectoroffset + i];
			i++;
		}
		c -= currsize;
		ptr += (currsize * 2);
		pos += (currsize * 2);
		continue;
	}

	sectortabel[allocedfild[current_pointer]] = 0x0;
	allocedfild[current_pointer] = mappoffset*2; //set new slot
	asd = (u16*)(greatownfilebuffer + current_pointer * chucksize);
	sectortabel[mappoffset*2] = (u32)asd;
	readSectorslocked(sectortabel[mappoffset*2 + 1], chucksizeinsec, asd);
	
	#ifdef countpagefault
	pagefehler++; //pagefaults
	#endif

	
	current_pointer++;
	if(current_pointer == buffslots)current_pointer = 0;
	int i = 0; //copy
	while(currsize > i){
		*(u16*)(&ptr[i*2]) = asd[sectoroffset + i];
		i++;
	}
	c -= currsize;
	ptr += (currsize * 2);
	pos += (currsize * 2);
	}

}
}

void generatefilemap(int size){

//very important to link
extern u32 *sectortabel;
extern u8 * greatownfilebuffer;
extern u32 allocedfild[buffslots];

	FILE_STRUCT* file = (FILE_STRUCT*)(lastopen);
	lastopenlocked = lastopen; //copy
	PARTITION* partition;
	uint32_t cluster;
	int clusCount;
	partition = file->partition;
	partitionlocked = partition;

	readSectorslocked = file->partition->disc->readSectors;
	iprintf("generating file map (size %d Byte)",((size/chucksize) + 1)*8);
	sectortabel =(u32*)malloc(((size/chucksize) + 1)*8); //alloc for size every Sector has one u32
	greatownfilebuffer =(u8*)malloc(chucksize * buffslots);

	clusCount = size/partition->bytesPerCluster;
	cluster = file->startCluster;

	//set sectortable to zero, every 2*i index, clusCount ammount of current partition, sector times one cluster
	int i = 0;
	while(i < ( (( ((int)partition->bytesPerCluster)/chucksize)*clusCount)+1) ){
		sectortabel[i*2] = 0x0;
		i++;
	}
	i = 0;
	//fill allocedfield with ones til top
	while(i < buffslots){
		allocedfild[i] = 0x1;
		i++;
	}
	int mappoffset = 0;
	i = 0;
	//store every sector of the opened file in sector table (1..)
	while(i < ( (((int)partition->bytesPerCluster)/ chucksize)) ){
		sectortabel[mappoffset*2 + 1] = _FAT_fat_clusterToSector(partition, cluster) + i;
		mappoffset++;
		i++;
	}
	//if more clusters are to be processed
	while (clusCount > 0) {
		clusCount--;
		//set the current cluster
		cluster = _FAT_fat_nextCluster (partition, cluster);
		i = 0;
		//then continue storing sectors until clusters per file runs out (n..)
		while(i < ( ((int)partition->bytesPerCluster)/chucksize) ){
			sectortabel[mappoffset*2 + 1] = _FAT_fat_clusterToSector(partition, cluster) + i;
			mappoffset++;
			i++;
		}
	}

//iprintf("bytes per cluster: %d \n",(int)partition->bytesPerCluster);
//iprintf("cluster initial address: %x \n",file->startCluster);
//iprintf("ammount of sectors of GBA game: %x \n",(((((int)partition->bytesPerCluster)/chucksize)*(int)partition->bytesPerCluster)+1)); //
//iprintf("sector tabel \n");
//	for(i=0;i<32;i++){
//	iprintf("%08X ",*(sectortabel+((i*2)+1)));
//}
//iprintf("\n (at ichfly.c)");

}

//not used
void getandpatchmap(int offsetgba,int offsetthisfile){
	FILE_STRUCT* file = (FILE_STRUCT*)(lastopen);
	PARTITION* partition;
	uint32_t cluster;
	int clusCount;
	partition = file->partition;

	clusCount = offsetthisfile/partition->bytesPerCluster;
	cluster = file->startCluster;

	int offset1 = (offsetthisfile/chucksize) % partition->bytesPerCluster;

	int mappoffset = offsetthisfile/chucksize;
	while (clusCount > 0) {
		clusCount--;
		cluster = _FAT_fat_nextCluster (partition, cluster);
	}
	sectortabel[mappoffset*2 + 1] = _FAT_fat_clusterToSector(partition, cluster) + offset1;
}
